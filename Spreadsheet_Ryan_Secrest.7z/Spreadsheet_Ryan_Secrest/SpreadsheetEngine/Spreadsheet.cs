﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpreadsheetEngine
{
    internal class Spreadsheet
    {
        public Spreadsheet(int rowNum, int colNum)
        {
            int[,] sheet = new int[rowNum, colNum];
        }

        

    }
}
